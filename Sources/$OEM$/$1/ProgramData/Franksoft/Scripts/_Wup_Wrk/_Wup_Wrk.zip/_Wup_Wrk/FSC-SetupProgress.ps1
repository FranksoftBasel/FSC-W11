Add-Type -AssemblyName PresentationFramework

$ProgressFile = "C:\ProgramData\Franksoft\Logs\SetupComplete-Progress.txt"

[xml]$xaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        Title="Franksoft Deployment"
        Width="650"
        Height="260"
        WindowStartupLocation="CenterScreen"
        Topmost="True"
        ResizeMode="NoResize"
        WindowStyle="ToolWindow">
    <Grid Margin="24">
        <Grid.RowDefinitions>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="50"/>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="Auto"/>
        </Grid.RowDefinitions>

        <TextBlock Grid.Row="0"
                   Text="Franksoft Deployment"
                   FontSize="26"
                   FontWeight="Bold"
                   Foreground="#003366"/>

        <ProgressBar Grid.Row="1"
                     Name="ProgressBar"
                     Height="24"
                     Minimum="0"
                     Maximum="100"
                     Margin="0,20,0,0"/>

        <TextBlock Grid.Row="2"
                   Name="PercentText"
                   FontSize="18"
                   FontWeight="Bold"
                   Margin="0,18,0,0"
                   Text="0%"/>

        <TextBlock Grid.Row="3"
                   Name="StatusText"
                   FontSize="18"
                   Margin="0,12,0,0"
                   Text="Windows Setup wird abgeschlossen..."/>
    </Grid>
</Window>
"@

$reader = New-Object System.Xml.XmlNodeReader $xaml
$window = [Windows.Markup.XamlReader]::Load($reader)

$bar = $window.FindName("ProgressBar")
$percent = $window.FindName("PercentText")
$status = $window.FindName("StatusText")

$timer = New-Object Windows.Threading.DispatcherTimer
$timer.Interval = [TimeSpan]::FromMilliseconds(700)

$timer.Add_Tick({
    if (Test-Path $ProgressFile) {
        $line = Get-Content $ProgressFile -Tail 1
        $parts = $line -split '\|',2

        if ($parts.Count -eq 2) {
            $value = [int]$parts[0]
            $text  = $parts[1]

            $bar.Value = $value
            $percent.Text = "$value%"
            $status.Text = $text

            if ($value -ge 100) {
                Start-Sleep -Seconds 2
                $window.Close()
            }
        }
    }
})

$timer.Start()
$window.ShowDialog()