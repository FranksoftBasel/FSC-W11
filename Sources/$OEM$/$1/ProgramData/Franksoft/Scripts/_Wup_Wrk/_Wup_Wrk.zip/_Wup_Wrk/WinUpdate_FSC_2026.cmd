@echo off
:: =====================================================================================
:: Script Name : WinUpdate_FSC.cmd
:: Version     : 4.5
:: Date        : 10.06.2026 - 00:34 
:: Author      : Franksoft
:: Description : FSC Windows Update Loader auf Basis der letzten funktionierenden Version
::
:: Wichtig
:: -------------------------------------------------------------------------------------
:: Basis: die bis heute funktionierende WinUpd-and-Reboot Logik.
:: FSC_WupStat_1..9, :Finish, RunOnce EndMsg und :Reboot bleiben erhalten.
:: PS1 Start bleibt mit start "" /wait, weil diese Rückgabe vorher funktionierte.
:: Winget-Block wurde entfernt, da Winget jetzt in WinGetUpdate_FSC.cmd ausgelagert ist.
:: Zusätzlich wird WinUpdate_FSC.log geschrieben.
::
:: Changelog
:: -------------------------------------------------------------------------------------
:: 4.5  09.06.2026 17:45  Restore der funktionierenden Rückgabe mit start /wait
:: =====================================================================================

COLOR 47
@MODE CON: COLS=80 LINES=14

Title Franksoft Client: Windows Update - Prepare....

@echo. 
@echo.  Franksoft Client: Windows Update - Prepare....
@echo. 
:: Brightness 40%
Powershell (Get-WmiObject -Namespace root/WMI -Class WmiMonitorBrightnessMethods).WmiSetBrightness(1,40) 1>NUL 2>NUL

SET FSC_STAGE=FSC_Windows_Update

net start dosvc 1>NUL 2>NUL


Timeout 10

@SET DBG=0
SET FSC_LOG="%ProgramData%\Franksoft\Logs\Franksoft Client.txt"
SET FSC_LOG_UPD="%ProgramData%\Franksoft\Logs\WinUpdate_FSC.log"
SET REG_WU=HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate
SET FSC_WinUpd_Script=%ProgramData%\Franksoft\Scripts\WinUpdate_FSC.cmd

:: GET Nice Time
@echo off
FOR /F "tokens=1-3 delims=:.," %%A IN ("%TIME%") DO (
    set H=%%A
    set M=%%B
    set S=%%C
)

SET H=%H: =%
IF %H% LSS 10 SET H=0%H%
SET NT=%H%:%M%:%S%

IF Not Exist "%PUBLIC%\Desktop\%~nx0" MD "%PUBLIC%\Desktop\%~nx0"
:: SET FSC WinUP Wallpaper
SET FSC-File2Ex=%ProgramData%\Franksoft\Scripts\WallP.exe
SET WallPaper=%ProgramData%\Franksoft\Scripts\WinUpd and Reboot.png
IF EXIST "%FSC-File2Ex%" IF EXIST "%WallPaper%" "%FSC-File2Ex%" "%WallPaper%"

SET FSC_TITLE_01=Franksoft Client: Windows Update - Prepare WLAN
SET FSC_TITLE_0x=Franksoft Client: Windows Update - Time: %NT:~0,8%
SET FSC_TITLE_LOG=Franksoft Client: Windows Update Start  - Time: %NT:~0,8%

set "Status2=00"

SET DOK=%ProgramData%\Franksoft\Scripts\DesktopOK\DesktopOK_Start.cmd

IF EXIST "%DOK%" CMD /C "%DOK%"
@echo.
for %%I in (1 2 3 4 5 6 7 8 9 10 11 12) do (
    if exist "%TEMP%\FSC_WupStat_%%I\" (
        set "Status2=%%I"
    )
)

SET UpdatePhase=0%Status2%/12
IF NOT Exist "%Temp%\FSC_WupStat_1" SET UpdatePhase=01/12

Title %FSC_TITLE_0x% - Phase ID: %UpdatePhase%

CLS
@echo. 
@echo.  %FSC_TITLE_0x% - Phase ID: %UpdatePhase%

SET "DesktopOK_PATH=%ProgramData%\Franksoft\Scripts\DesktopOK"
SET "DesktopOK_Exe=%DesktopOK_PATH%\DesktopOK.exe"
SET "DesktopOK_Profile=%DesktopOK_PATH%\FSC_Def.dok"
SET "DesktopOK_VBS=%DesktopOK_PATH%\DesktopOK_Start.vbs"

IF EXIST "%DesktopOK_Exe%" IF EXIST "%DesktopOK_Profile%" IF EXIST "%DesktopOK_VBS%" (
    wscript "%DesktopOK_VBS%"
)


Openfiles 2>NUL 1>&2
IF %ErrorLevel% equ 0 (Set Admin-Status=Yes) else (Set Admin-Status=No)

:: GET Windows Setup USB Drive letter
for %%i in (B D E F G H I J K L M N O P Q R S T U V W X Y Z) do @IF Exist %%i:\Sources\setup.exe set USB_Stick_Path=%%i:

:: GET Nice Time
FOR /F "tokens=1-3 delims=:.," %%A IN ("%TIME%") DO (
    set H=%%A
    set M=%%B
    set S=%%C
)

SET H=%H: =%
IF %H% LSS 10 SET H=0%H%
SET NT=%H%:%M%:%S%

Set VolApp1=%ProgramData%\Franksoft\Scripts\WinAudio3.ExE
If Exist "%VolApp1%" (
		Cmd /c Start "" "%VolApp1%" 1966 >NUL
)

:: Check and Connect

SET WFWI_Profile_Path=%ProgramData%\Franksoft\FSC-Apps\Wi-Fi-cfg
SET WFWI_Profile=%WFWI_Profile_Path%\WLAN-BatMan.xml
SET WFWI_Connect_Script=%WFWI_Profile_Path%\Connect Batman.cmd

IF Exist "%TEMP%\Wlan-Connectet-01" GOTO START2

IF EXIST "%WFWI_Profile%" IF EXIST "%WFWI_Connect_Script%" (
        Echo.     WLAN-Profile: Import Franksoft WLAN 
        CMD /c "%WFWI_Connect_Script%" >NUL
        MD %TEMP%\Wlan-Connectet-01 >NUL
	    Timeout 4 >NUL
) ELSE (
        Echo. - WLAN Profile File not found: %WFWI_Profile% >>%FSC_LOG%
	    Timeout 10 >NUL
)

CLS

:START2

:: Check if Done
IF EXIST "%TEMP%\FSC_WupStat_12" GOTO Finish
:: If Exist "%TEMP%\FSUPD7" Goto Finish

Color 60
CLS

@echo. 
@echo.  Franksoft Client: Windows Update - START
@echo. 


If Not Exist "%Temp%\Timeout1Done" @Timeout 12
CLS

:: SET /A Status+=1

:: Temp-Verzeichnis prÃ¼fen und Status setzen
FOR %%I IN (1 2 3 4 5 6 7 8 9 10 11 12) DO (
    IF NOT EXIST "%Temp%\FSC_WupStat_%%I" (
        MD "%Temp%\FSC_WupStat_%%I"
        SET Status=%%I
        REM Winget Block entfernt - ausgelagert nach WinGetUpdate_FSC.cmd
        GOTO EndCheckWUP
    )
)

:: -------------------------------------------------------------------------------------------------------------------------

:EndCheckWUP

SET Status=%UpdatePhase%
SET FSC_TITLE=Franksoft Client: Windows Update: Phase %UpdatePhase%
SET FSC_TITLE_0x=%FSC_TITLE%
SET FSC_LOG="%ProgramData%\Franksoft\Logs\Franksoft Client.txt"

:: SET /A Status+=1

@Echo. >>%FSC_LOG%
@Echo. %FSC_TITLE_LOG%>>%FSC_LOG%
@Echo. >>%FSC_LOG%

@Echo. - FSC Phase ID:   %UpdatePhase%>>%FSC_LOG%
@Echo. - Timestamp:      %Date% %NT%>>%FSC_LOG%
@Echo. - Executed by:    %UserName%>>%FSC_LOG%
@Echo. - Admin Status:   %Admin-Status%>>%FSC_LOG%
@Echo. - Script Path:    %~dp0%~nx0>>%FSC_LOG%
@Echo. >>%FSC_LOG%

@Echo. ============================================================>>%FSC_LOG_UPD%
@Echo. WinUpdate_FSC.cmd Start - Time: %NT:~0,8%>>%FSC_LOG_UPD%
@Echo. - FSC Phase ID:   %UpdatePhase%>>%FSC_LOG_UPD%
@Echo. - Timestamp:      %Date% %NT%>>%FSC_LOG_UPD%
@Echo. - Executed by:    %UserName%>>%FSC_LOG_UPD%
@Echo. - Admin Status:   %Admin-Status%>>%FSC_LOG_UPD%
@Echo. - Script Path:    %~dp0%~nx0>>%FSC_LOG_UPD%
@Echo. ============================================================>>%FSC_LOG_UPD%

CLS
echo. 

If Not Exist "%Temp%\Timeout1Done" MD "%Temp%\Timeout1Done"

:::::::::::::::::::::::::::::::::::::::::: START ::::::::::::::::::::::::::::::::::::::::::

:RUN
@COLOR 20


:: Franksoft Windows Update Phase %Status% Time: %NT%
:: Franksoft Client: Windows Update Prepare

@echo.  Franksoft Client: Windows Update - RUN
@echo.

EVENTCREATE /T INFORMATION /so Franksoft /ID 007 /l application /d "Franksoft Client: Windows Update Start Phase: %Status% %~nx0">Nul 2> Nul

@echo.   - Set Performance Power Scheme
@echo.   - Set Performance Power Scheme>>%FSC_LOG%

:: @echo. - Set Performance Power Scheme>>%FSC_LOG%
Powercfg -SetActive 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c
powercfg -change -monitor-timeout-ac 0 >NUL
powercfg -change -monitor-timeout-dc 0 >NUL

:: Disable UAC
REG ADD HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System /v EnableLUA /t REG_DWORD /d 0 /f >NUL

:: SET NuGetCFG=%AppData%\NuGet\nuget.config
SET NuGetCFG=%ProgramFiles%\PackageManagement\ProviderAssemblies\nuget
If Not Exist "%NuGetCFG%" @echo.   - Install: PS Module PackageProvider "NuGet"
:: If Not Exist "%NuGetCFG%" Start /min "" Powershell.exe Install-PackageProvider -Name "NuGet" -Confirm:$false -Force -Verbose >NUL
:: If Not Exist "%NuGetCFG%" Powershell.exe Install-PackageProvider -Name "NuGet" -Confirm:$false -Force -Verbose >NUL
If Not Exist "%NuGetCFG%" Powershell.exe Install-PackageProvider -Name "NuGet" -Confirm:$false -Force >NUL

SET PSWINUPDPATH=%ProgramFiles%\WindowsPowerShell\Modules\PSWindowsUpdate
If Not Exist "%PSWINUPDPATH%" @echo.   - Install: PS Module PSWindowsUpdate
If Not Exist "%PSWINUPDPATH%" Powershell.exe Install-Module PSWindowsUpdate -Force >NUL

If Not Exist "%PSWINUPDPATH%" @echo.   - Install: PS Module PSWindowsUpdate 
If Not Exist "%PSWINUPDPATH%" Powershell.exe Import-Module PSWindowsUpdate -Force >NUL

:: @color e0

SET NT=%TIME: =0%

REM ---------------------------------------------------------------------------
REM FSC Driver Update GPO Steuerung
REM Phase 01-05 : Treiber blockiert
REM Phase 06-12 : Treiber freigegeben
REM ---------------------------------------------------------------------------

IF EXIST "%TEMP%\FSC_WupStat_6" GOTO DriverPolicyEnable

:DriverPolicyBlock
REG ADD "%REG_WU%" /v ExcludeWUDriversInQualityUpdate /t REG_DWORD /d 1 /f >NUL 2>NUL
@echo.   - Windows Update Driver Updates: blocked
IF DEFINED FSC_LOG @echo.   - Windows Update Driver Updates: blocked>>%FSC_LOG%
IF DEFINED FSC_LOG_UPD @echo.   - Windows Update Driver Updates: blocked>>%FSC_LOG_UPD%
GOTO DriverPolicyDone

:DriverPolicyEnable
REG DELETE "%REG_WU%" /v ExcludeWUDriversInQualityUpdate /f >NUL 2>NUL
@echo.   - Windows Update Driver Updates: enabled
IF DEFINED FSC_LOG @echo.   - Windows Update Driver Updates: enabled>>%FSC_LOG%
IF DEFINED FSC_LOG_UPD @echo.   - Windows Update Driver Updates: enabled>>%FSC_LOG_UPD%

net stop wuauserv >NUL 2>NUL
net start wuauserv >NUL 2>NUL
timeout /t 5 /nobreak >NUL

:DriverPolicyDone

REM ---------------------------------------------------------------------------
REM Franksoft Windows Update V4 Starter
REM Startet FSC-Wup-V4.ps1 und wartet auf Rückgabe
REM ---------------------------------------------------------------------------

SET FSC_WUP_PS1=%ProgramData%\Franksoft\Scripts\FSC-Wup-V4.ps1

@echo.   - Franksoft Windows Update (WPF V4)
IF DEFINED FSC_LOG @echo.   - Franksoft Windows Update (WPF V4)>>%FSC_LOG%
IF DEFINED FSC_LOG_UPD @echo.   - Franksoft Windows Update (WPF V4)>>%FSC_LOG_UPD%

IF EXIST "%FSC_WUP_PS1%" (
    start "" /wait Powershell.exe ^
    -NoLogo ^
    -NoProfile ^
    -ExecutionPolicy Bypass ^
    -STA ^
    -WindowStyle Hidden ^
    -File "%FSC_WUP_PS1%"
) ELSE (
    echo.
    echo.   * NOT found: "%FSC_WUP_PS1%"
    IF DEFINED FSC_LOG echo.   * NOT found: "%FSC_WUP_PS1%">>%FSC_LOG%
)

REM Danach geht dein bestehendes CMD normal weiter
REM Goto Reboot

@echo. >>%FSC_LOG%
@echo. Franksoft Client: Windows Update Reboot - Time: %NT:~0,8%>>%FSC_LOG%

Goto Reboot

:: -------------------------------------------------------------------------------------------------------------------------

:Finish

REM ---------------------------------------------------------------------------
REM FSC Driver Update GPO Cleanup
REM ---------------------------------------------------------------------------
REG DELETE "%REG_WU%" /v ExcludeWUDriversInQualityUpdate /f >NUL 2>NUL
IF DEFINED FSC_LOG @echo.   - Windows Update Driver Updates: policy cleanup>>%FSC_LOG%
IF DEFINED FSC_LOG_UPD @echo.   - Windows Update Driver Updates: policy cleanup>>%FSC_LOG_UPD%


Title %FSC_TITLE_LOG%  - Phase ID: %UpdatePhase% - Time: %NT%

:: SET Last Wallpaper
SET FSC-File2Ex=%ProgramData%\Franksoft\Scripts\WallP.exe
SET WallPaper=%SystemRoot%\Web\4K\Wallpaper\Windows\FSC_Final_W11_01.jpg
IF EXIST "%FSC-File2Ex%" IF EXIST "%WallPaper%" "%FSC-File2Ex%" "%WallPaper%"

reg add "HKCU\Control Panel\Colors" /v Background /t REG_SZ /d "7 25 99" /f >NUL
RUNDLL32.EXE user32.dll,UpdatePerUserSystemParameters

SET RK_UAC=HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System

SET UAC_ON=%ProgramData%\Franksoft\Scripts\UAC-DEF.reg
If Exist "%UAC_ON%" (
    @Echo.
    @Echo.   - Windows UAC: Enable>>%FSC_LOG%
    Regedit /s "%UAC_ON%"
    REG ADD %RK_UAC% /v EnableLUA /t REG_DWORD /d 1 /f >NUL
) ELSE (
    @Echo.   * NOT found Windows UAC: "%UAC_ON%">>%FSC_LOG%
    REG ADD %RK_UAC% /v EnableLUA /t REG_DWORD /d 1 /f >NUL
)

@Echo.   - System Restore: Enable>>%FSC_LOG%
cmd /c Powershell.exe -EP Bypass enable-computerrestore -drive c:\ >NUL

:: Gen Logfile from FS Update Log
SET FSC_LogLnk=%ProgramData%\Franksoft\Scripts\Windows Update LogFile (FS).lnk
If Exist "%FSC_LogLnk%" CMD /C Start "" "%FSC_LogLnk%"
:: Not Working from CMD
:: Powershell Get-WinEvent -FilterHashtable @{logname='system'; id=19} | Out-File $Env:ProgramData\Franksoft\Logs\FSC-Appx-Update.txt -Width 250


@Echo.
@Echo.   - Power Plan: Change to Balanced>>%FSC_LOG%
@Echo.   - Power Plan: Change to Balanced

Powercfg -SetActive 381b4222-f694-41f0-9685-ff5bb260df2e >NUL

@Echo.    - AC Monitor-timeout 10>>%FSC_LOG%
@Echo.    - DC Monitor-timeout 05>>%FSC_LOG%
@Echo.    - AC HardDisk-timeout 22>>%FSC_LOG%
@Echo.    - DC HardDisk-timeout 11>>%FSC_LOG%
@Echo.    - AC Standby-timeout 20>>%FSC_LOG%
@Echo.    - DC Standby-timeout 15>>%FSC_LOG%

:: Disable Monitor Timeout

@Echo.   - Disable: Monitor Timeout>>%FSC_LOG%
@Echo.   - Disable: Monitor Timeout

powercfg -change -monitor-timeout-ac 10 >NUL
powercfg -change -monitor-timeout-dc 5 >NUL

:: Change HardDisk Timeout
powercfg -change -disk-timeout-ac 22 >NUL
powercfg -change -disk-timeout-dc 11 >NUL

:: Change Sleep Timeout (Energiesparmodus)
powercfg -change -standby-timeout-ac 20 >NUL
powercfg -change -standby-timeout-dc 15 >NUL

@Echo.   - Disable: Hybrid Standbymode>>%FSC_LOG%
@Echo.   - Disable: Hybrid Standbymode

:: Disable Hybrid Standby
powercfg -setacvalueindex SCHEME_CURRENT SUB_SLEEP HYBRIDSLEEP 0
powercfg -setdcvalueindex SCHEME_CURRENT SUB_SLEEP HYBRIDSLEEP 0
powercfg -SetActive SCHEME_CURRENT

SET FSC_TITLE=Franksoft Client: Windows Update Completed
IF DEFINED FSC_LOG_UPD @Echo. %FSC_TITLE%>>%FSC_LOG_UPD%

:: 2 Debug
:: @Echo.   - Datentraegerbereinigung wird ausgefuehrt......
:: @Echo.   - DatentrÃ¤gerbereinigung wird ausgefÃ¼hrt>>%FSC_LOG%
:: @cleanmgr /sagerun:65535

EVENTCREATE /T INFORMATION /so Franksoft /ID 007 /l application /d "Franksoft Client: Windows Update End   Phase: %Status% %~nx0" >NUL

:: Add Final FSC Scripts
SET REGKEY-RunOnce=HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce
SET FSC_Scripts_Local=%ProgramData%\Franksoft\Scripts
SET Audio_SCR=%FSC_Scripts_Local%\PlayAudio.vbs
SET FSC-ENDMSG_VBS=%FSC_Scripts_Local%\FSC-Complete.VBS
SET FSC_END_DOK=%ProgramData%\Franksoft\Scripts\DesktopOK\DesktopOK_Start.cmd

REG ADD "%REGKEY-RunOnce%" /v 01-FSC_END_Sound /d "CMD /c CScript %Audio_SCR% //Nologo //T:05" /f >NUL
REG ADD "%REGKEY-RunOnce%" /v 02-FSC-DesktopOK /d "CMD /c %FSC_END_DOK%" /f >NUL
REG ADD "%REGKEY-RunOnce%" /v 03-FSC_END_CleanMgr /d "cleanmgr /sagerun:65535" /f >NUL
REG ADD "%REGKEY-RunOnce%" /v 04-FSC_END_MSG /d "%FSC-ENDMSG_VBS%" /f >NUL
IF DEFINED FSC_LOG_UPD @Echo. RunOnce EndMsg gesetzt: %FSC-ENDMSG_VBS%>>%FSC_LOG_UPD%

EVENTCREATE /T INFORMATION /so Franksoft /ID 007 /l application /d "Franksoft Client: Windows Update Completed">Nul 2> Nul
schtasks /delete /tn "Franksoft Windows Update" /f >NUL
IF Exist "%PUBLIC%\Desktop\%~nx0" RD /S/Q "%PUBLIC%\Desktop\%~nx0"

RD /S/Q "%TEMP%" >NUL
MD "%TEMP%" >NUL

RD /S/Q C:\Temp >NUL
MD C:\Temp >NUL

@Echo. >>%FSC_LOG%
@Echo. %FSC_TITLE%>>%FSC_LOG%
@Echo. >>%FSC_LOG%
@Echo.************************************************************************************* >>%FSC_LOG%
@Echo. >>%FSC_LOG%
IF DEFINED FSC_LOG_UPD @Echo. WinUpdate_FSC.cmd Finish erreicht - RunOnce/EndMsg vorbereitet>>%FSC_LOG_UPD%
IF DEFINED FSC_LOG_UPD @Echo. ============================================================>>%FSC_LOG_UPD%

Goto Reboot

:Reboot

SET TIMER=15

:: COLOR 47

@CLS
@Echo.
@Echo.
@Echo. - Reboot in 10Sec...
@Echo.
@Echo.

SET FSC-MSG01=Franksoft: Windows Update - Reboot in %Timer% sec
SET PSShutDownScr=%ProgramData%\Franksoft\Scripts\FS-Shutdown.ps1
SET PSShutDownEx=Powershell.exe -EP ByPass -NoLogo -NonInteractive -NoProfile -WindowStyle Hidden -File "%PSShutDownScr%"

IF Exist "%PSShutDownScr%" ( 
            %PSShutDownEx% 
) else (
            Shutdown -r -f -t %Timer% /c "%FSC-MSG01%"
)

Exit /b