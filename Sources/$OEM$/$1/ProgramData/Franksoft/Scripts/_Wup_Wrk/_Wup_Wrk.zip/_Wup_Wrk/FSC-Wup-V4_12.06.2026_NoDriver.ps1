# ==================================================================================================
# FSC-Wup-V4.6.ps1 - 00:52 10.06.2026
# Franksoft Windows Update WPF Frontend
# Stand: geprüft + Fixes 
#
# Enthaltene Fixes:
# - Global Mutex gegen Doppelstart
# - Franksoft Logo per Variable
# - kompaktes WPF Layout
# - Update läuft im Background-Runspace
# - Install-WindowsUpdate nahe an altem CMD mit -ComputerName
# - -ForceInstall und ConfirmPreference gegen PSWindowsUpdate Eingabeaufforderungen
# - PSWindowsUpdate schreibt in eigenes Raw-Log gegen File-Locks
# - Heartbeat mit Add-Content / ErrorAction SilentlyContinue
# - Idle-Fallback ohne harten Fehler
# - WARNUNG statt harter Fehler bei PSWindowsUpdate Exceptions
# - Treiberphase separat: erst wenn keine Microsoft Updates mehr vorhanden sind
# ==================================================================================================

$script:Mutex = New-Object System.Threading.Mutex($false, "Global\Franksoft-WUP")

if (-not $script:Mutex.WaitOne(0, $false)) {
    exit 0
}

$ErrorActionPreference = "Continue"
$ProgressPreference = "SilentlyContinue"
$VerbosePreference = "SilentlyContinue"
$InformationPreference = "SilentlyContinue"

try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}

$BaseDir  = "$env:ProgramData\Franksoft"
$LogDir   = Join-Path $BaseDir "Logs"
$LogFile  = Join-Path $LogDir "WindowsUpdate.log"
$PSWUFile = Join-Path $LogDir "PSWindowsUpdate.raw.log"
$LogoFile = Join-Path $BaseDir "Scripts\Franksoft.png"
$GuiLogFile = Join-Path $LogDir "WinUpdate_FSC_GUI.txt"
$CmdLogFile = Join-Path $LogDir "WinUpdate_FSC.log"

# ----------------------------------------------------------------------
# Unicode Helper FSC
# ----------------------------------------------------------------------

$FS_AE = [char]0x00E4
$FS_OE = [char]0x00F6
$FS_UE = [char]0x00FC

$FS_AE_GROSS = [char]0x00C4
$FS_OE_GROSS = [char]0x00D6
$FS_UE_GROSS = [char]0x00DC

$FS_SS  = [char]0x00DF
$FS_DOT = [char]0x00B7

New-Item -ItemType Directory -Path $LogDir -Force | Out-Null

"============================================================" | Out-File $LogFile -Append -Encoding UTF8
"Franksoft Windows Update V4.0 Start: $(Get-Date -Format 'dd.MM.yyyy HH:mm:ss')" | Out-File $LogFile -Append -Encoding UTF8
"Computer: $env:COMPUTERNAME" | Out-File $LogFile -Append -Encoding UTF8
"PID: $PID" | Out-File $LogFile -Append -Encoding UTF8

Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase

$XamlText = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Franksoft Windows Update"
        Width="980"
        Height="640"
        WindowStartupLocation="CenterScreen"
        ResizeMode="CanMinimize"
        Background="#F4F6FA"
        FontFamily="Segoe UI">
    <Grid>
        <Grid.RowDefinitions>
            <RowDefinition Height="70"/>
            <RowDefinition Height="500"/>
        </Grid.RowDefinitions>

        <Border Grid.Row="0" Background="#075CC8">
            <Grid Margin="36,0,36,0">
                <Grid.ColumnDefinitions>
                    <ColumnDefinition Width="72"/>
                    <ColumnDefinition Width="*"/>
                </Grid.ColumnDefinitions>

                <Image Source="__LOGO__"
                       Width="42"
                       Height="42"
                       VerticalAlignment="Center"
                       Stretch="Uniform"/>

                <StackPanel Grid.Column="1" VerticalAlignment="Center" Margin="18,0,0,0">
                    <TextBlock Text="Franksoft Windows Update"
                               Foreground="White"
                               FontSize="20"
                               FontWeight="Bold"/>
                    <TextBlock Name="HeaderSubText"
                               Text="Phase 03/09 · Vorbereitung"
                               Foreground="#D9EAFF"
                               FontSize="14"
                               Margin="2,2,0,0"/>
                </StackPanel>
            </Grid>
        </Border>

        <Grid Grid.Row="1" Margin="40,18,40,18">
            <Grid.RowDefinitions>
                <RowDefinition Height="88"/>
                <RowDefinition Height="70"/>
                <RowDefinition Height="*"/>
                <RowDefinition Height="30"/>
            </Grid.RowDefinitions>

            <Border Grid.Row="0"
                    Background="White"
                    CornerRadius="12"
                    BorderBrush="#E0E4EC"
                    BorderThickness="1">
                <StackPanel Margin="22,14,22,10">
                    <TextBlock Text="Aktueller Status"
                               Foreground="#707A88"
                               FontSize="14"/>
                    <TextBlock Name="CurrentUpdateText"
                               Text="Windows Update wird vorbereitet..."
                               Foreground="#1E2B3C"
                               FontSize="18"
                               Margin="0,8,0,0"
                               TextTrimming="CharacterEllipsis"/>
                </StackPanel>
            </Border>

            <StackPanel Grid.Row="1" Margin="0,14,0,0">
                <Grid>
                    <TextBlock Text="Fortschritt"
                               Foreground="#707A88"
                               FontSize="14"/>
                    <TextBlock Name="PercentText"
                               Text="arbeitet..."
                               Foreground="#1E2B3C"
                               FontWeight="Bold"
                               HorizontalAlignment="Right"
                               FontSize="16"/>
                </Grid>
                <ProgressBar Name="ProgressBar"
                             Height="22"
                             Margin="0,8,0,0"
                             IsIndeterminate="True"/>
            </StackPanel>

            <Border Grid.Row="2"
                    Background="White"
                    CornerRadius="12"
                    BorderBrush="#E0E4EC"
                    BorderThickness="1">
                <StackPanel Margin="18,12,18,12">
                    <TextBlock Text="Windows Update Log"
                               Foreground="#707A88"
                               FontSize="14"/>
                    <TextBox Name="LogTextBox"
                             Margin="0,8,0,0"
                             Height="350"
                             IsReadOnly="True"
                             BorderThickness="0"
                             Background="White"
                             Foreground="#1E2B3C"
                             FontFamily="Consolas"
                             FontSize="13"
                             TextWrapping="NoWrap"
                             VerticalScrollBarVisibility="Auto"
                             HorizontalScrollBarVisibility="Auto"/>
                </StackPanel>
            </Border>

            <TextBlock Grid.Row="3"
                       Name="BottomText"
                       Text="Bitte den Computer nicht ausschalten."
                       Foreground="#606A78"
                       FontSize="14"
                       VerticalAlignment="Bottom"/>
        </Grid>
    </Grid>
</Window>
"@

$XamlText = $XamlText.Replace("__LOGO__", $LogoFile)
[xml]$Xaml = $XamlText

$Reader = New-Object System.Xml.XmlNodeReader $Xaml
$Window = [Windows.Markup.XamlReader]::Load($Reader)

$CurrentUpdateText = $Window.FindName("CurrentUpdateText")
$HeaderSubText     = $Window.FindName("HeaderSubText")
$PercentText       = $Window.FindName("PercentText")
$ProgressBar       = $Window.FindName("ProgressBar")
$LogTextBox        = $Window.FindName("LogTextBox")
$BottomText        = $Window.FindName("BottomText")


function Write-GUILog {
    param([string]$Text)

    if ([string]::IsNullOrWhiteSpace($Text)) {
        return
    }

    try {

        $Line = "$(Get-Date -Format 'HH:mm:ss')  $Text"

        $Lines = @()

        if (Test-Path $GuiLogFile) {
            $Lines += Get-Content $GuiLogFile -ErrorAction SilentlyContinue
        }

        $Lines += $Line

        $Lines = $Lines | Select-Object -Last 15

        [System.IO.File]::WriteAllLines(
            $GuiLogFile,
            $Lines,
            [System.Text.Encoding]::UTF8
        )

    } catch {
        Write-FSCLog "GUI LOG ERROR: $($_.Exception.Message)"
    }
}

function Test-DownloadActivity {
    try {
        $RecentDownloadEvents = Get-WinEvent `
            -LogName "Microsoft-Windows-WindowsUpdateClient/Operational" `
            -MaxEvents 50 `
            -ErrorAction SilentlyContinue |
            Where-Object {
                $_.TimeCreated -gt (Get-Date).AddMinutes(-2) -and
                $_.Id -eq 41
            }

        if ($RecentDownloadEvents) {
            return $true
        }
    } catch {}

    return $false
}

$UpdateScript = {
    param(
        [string]$LogFile,
        [string]$PSWUFile,
        [string]$GuiLogFile
    )

    $ErrorActionPreference = "Continue"
    $ProgressPreference = "SilentlyContinue"
    $VerbosePreference = "SilentlyContinue"
    $InformationPreference = "SilentlyContinue"

    try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}

function Write-FSCLog {
    param([string]$Text)
    if ([string]::IsNullOrWhiteSpace($Text)) { return }

    try {
        Add-Content -Path $LogFile `
                    -Value "$(Get-Date -Format 'dd.MM.yyyy HH:mm:ss')  $Text" `
                    -Encoding UTF8 `
                    -ErrorAction SilentlyContinue
    } catch {}
}

function Write-GUILog {
    param([string]$Text)

    if ([string]::IsNullOrWhiteSpace($Text)) { return }

    try {
        $Line = "$(Get-Date -Format 'HH:mm:ss')  $Text"

        $Lines = @()
        if (Test-Path $GuiLogFile) {
            $Lines += Get-Content $GuiLogFile -ErrorAction SilentlyContinue
        }

        $Lines += $Line
        $Lines = $Lines | Select-Object -Last 15

        [System.IO.File]::WriteAllLines(
            $GuiLogFile,
            $Lines,
            [System.Text.Encoding]::UTF8
        )
    } catch {}
}


    Write-FSCLog "Runspace gestartet."
    Write-FSCLog "Lade PSWindowsUpdate Modul..."

    try {
        Import-Module PSWindowsUpdate -Force -ErrorAction Stop
        Write-FSCLog "PSWindowsUpdate Modul geladen."
    }
    catch {
        Write-FSCLog "FEHLER: PSWindowsUpdate Modul konnte nicht geladen werden."
        Write-FSCLog $_.Exception.Message
        return 10
    }

    try {
        Write-FSCLog "Suche Windows Updates..."

        $Updates = Get-WindowsUpdate `
            -AcceptAll `
            -IgnoreReboot `
            -ErrorAction Continue

        if (!$Updates -or $Updates.Count -eq 0) {
            Write-FSCLog "Keine Updates gefunden."
            return 0
        }

        Write-FSCLog "Gefundene Updates: $($Updates.Count)"

        # FSC V4.0: Microsoft Updates zuerst, Treiber nur zählen/loggen.
        # Treiber werden NICHT in Phase 03 installiert.
        $MSUpdates = @()
        $DriverUpdates = @()

        foreach ($U in $Updates) {

            if ($U.Title -match 'KB\d+' -or
                $U.Title -match '\.NET' -or
                $U.Title -match 'Sicherheitsupdate' -or
                $U.Title -match 'Security' -or
                $U.Title -match 'Defender' -or
                $U.Title -match 'Malicious Software Removal Tool') {

                $MSUpdates += $U
                continue
            }

            if ($U.Title -match 'Driver|Treiber|Intel|Realtek|HP|ELAN|Lenovo|Dell|ASUS|Extension|Firmware|Bluetooth|Audio|Graphics|Display|Net|WLAN|Wireless') {
                $DriverUpdates += $U
            }
            else {
                $MSUpdates += $U
            }
        }

        Write-FSCLog "Microsoft Updates: $($MSUpdates.Count)"
        Write-FSCLog "Treiber Updates:   $($DriverUpdates.Count)"

        Write-GUILog "Gefundene Updates: $($Updates.Count)"
        Write-GUILog "Microsoft Updates: $($MSUpdates.Count)"
        Write-GUILog "Treiber Updates: $($DriverUpdates.Count)"

        if ($DriverUpdates.Count -gt 0) {
            foreach ($D in $DriverUpdates) {
                Write-FSCLog "DRIVER WAIT: $($D.Title)"
            }
        }

        # ------------------------------------------------------------------
        # Phase 03A: Microsoft Updates zuerst
        # ------------------------------------------------------------------
        if ($MSUpdates -and $MSUpdates.Count -gt 0) {

            if ($DriverUpdates.Count -gt 0) {
                Write-FSCLog "Treiber werden in dieser Runde NICHT installiert."
                Write-GUILog "Treiber warten auf separate Runde"
            }

            $Counter = 0
            foreach ($Update in $MSUpdates) {
                $Counter++
                Write-FSCLog "MS WAIT [$Counter/$($MSUpdates.Count)] $($Update.Title)"
            }

            Write-GUILog "Microsoft Update Installation startet"
            Write-FSCLog "Microsoft Update Installation startet."
            Write-FSCLog ">>> Install-WindowsUpdate MICROSOFT START <<<"

            $Error.Clear()
            $ConfirmPreference = 'None'

            Remove-Item $PSWUFile -Force -ErrorAction SilentlyContinue

            Install-WindowsUpdate `
                -ComputerName $env:COMPUTERNAME `
                -AcceptAll `
                -IgnoreReboot `
                -NotCategory "Drivers" `
                -Confirm:$false `
                -ForceInstall `
                -Verbose `
                *>> $PSWUFile

            Write-FSCLog ">>> Install-WindowsUpdate MICROSOFT ENDE <<<"
        }
        # ------------------------------------------------------------------
        # Phase 03B: Treiber erst installieren, wenn keine Microsoft Updates mehr da sind
        # ------------------------------------------------------------------
        elseif ($DriverUpdates -and $DriverUpdates.Count -gt 0) {

            Write-FSCLog "Keine Microsoft Updates gefunden."
            Write-FSCLog "Treiber Updates vorhanden: $($DriverUpdates.Count)"
            Write-GUILog "Keine Microsoft Updates gefunden"
            Write-GUILog "Treiber Update Installation startet"

            $Counter = 0
            foreach ($Driver in $DriverUpdates) {
                $Counter++
                Write-FSCLog "DRIVER INSTALL WAIT [$Counter/$($DriverUpdates.Count)] $($Driver.Title)"
            }

            Write-FSCLog ">>> Install-WindowsUpdate TREIBER START <<<"

            $Error.Clear()
            $ConfirmPreference = 'None'

            Remove-Item $PSWUFile -Force -ErrorAction SilentlyContinue

            Install-WindowsUpdate `
                -ComputerName $env:COMPUTERNAME `
                -AcceptAll `
                -IgnoreReboot `
                -Category "Drivers" `
                -Confirm:$false `
                -ForceInstall `
                -Verbose `
                *>> $PSWUFile

            Write-FSCLog ">>> Install-WindowsUpdate TREIBER ENDE <<<"
        }
        else {
            Write-FSCLog "Keine Microsoft Updates und keine Treiber Updates gefunden."
            Write-GUILog "Keine Updates gefunden"
            return 0
        }

        if (Test-Path $PSWUFile) {
            try {
                Add-Content -Path $LogFile `
                            -Value "----- PSWindowsUpdate Raw Log -----" `
                            -Encoding UTF8 `
                            -ErrorAction SilentlyContinue

                Get-Content $PSWUFile -ErrorAction SilentlyContinue |
                    Out-File $LogFile -Append -Encoding UTF8
            } catch {}
        }

        Write-FSCLog "LASTEXITCODE: $LASTEXITCODE"
        Write-FSCLog "PowerShell ErrorCount: $($Error.Count)"

        if ($Error.Count -gt 0) {
            Write-FSCLog "WARNUNG: Während Windows Update wurden Fehler/Warnungen gemeldet."
            foreach ($Err in $Error) {
                Write-FSCLog "ERROR: $($Err.Exception.Message)"
            }
        }

        Write-FSCLog "Prüfe verbleibende Updates..."

        try {
            $Remaining = Get-WindowsUpdate `
                -AcceptAll `
                -IgnoreReboot `
                -ErrorAction Continue

            if ($Remaining) {
                Write-FSCLog "Verbleibende Updates: $($Remaining.Count)"
                foreach ($R in $Remaining) {
                    Write-FSCLog "REMAINING: $($R.Title)"
                }
            }
            else {
                Write-FSCLog "Verbleibende Updates: 0"
            }
        }
        catch {
            Write-FSCLog "Nachprüfung konnte nicht ausgeführt werden."
            Write-FSCLog $_.Exception.Message
        }

        Write-FSCLog "Update Installation abgeschlossen."
        return 0
    }
    catch {
        Write-FSCLog "WARNUNG während Windows Update."
        Write-FSCLog $_.Exception.Message
        Write-FSCLog $_.ScriptStackTrace

        # Kein harter Fehler für FSC.
        # Windows Update kann trotz PSWindowsUpdate-Warnung weiter installieren.
        return 0
    }
}

$Window.Add_ContentRendered({

    $script:UpdateRound = 1

    try {
        $CmdLogFile = Join-Path $LogDir "WinUpdate_FSC.log"

        if (Test-Path $CmdLogFile) {
            $RoundCount = (
                Select-String `
                    -Path $CmdLogFile `
                    -Pattern "WinUpdate_FSC.cmd Start" `
                    -ErrorAction SilentlyContinue
            ).Count

            if ($RoundCount -gt 0) {
                $script:UpdateRound = $RoundCount
            }
        }
    } catch {
        $script:UpdateRound = 1
    }

    $HeaderSubText.Text = "Phase 03 - Runde $($script:UpdateRound)"
    $CurrentUpdateText.Text = "Windows Update startet..."
    $BottomText.Text = "Windows Update arbeitet im Hintergrund. Bitte warten..."

    Write-GUILog "Windows Update Runde $script:UpdateRound"
    Write-GUILog "Windows Update Suche gestartet"
    
$script:StartTime = Get-Date
$script:LastHeartbeat = Get-Date
$script:LastRealActivity = Get-Date
$script:LastDownloadEvent = [DateTime]::MinValue
$script:LastDownloadLog   = [DateTime]::MinValue
$script:LastDownloadPoll  = [DateTime]::MinValue
$script:IdleTimeoutSeconds = 300
$script:ExitCode = $null

$script:UpdateRound = 1

try {
    if (Test-Path $CmdLogFile) {
        $RoundCount = (
            Select-String `
                -Path $CmdLogFile `
                -Pattern "WinUpdate_FSC.cmd Start" `
                -ErrorAction SilentlyContinue
        ).Count

        if ($RoundCount -gt 0) {
            $script:UpdateRound = $RoundCount
        }
    }
} catch {
    $script:UpdateRound = 1
}

$script:LastLineCount = 0


    if (Test-Path $LogFile) {
        try { $script:LastLineCount = @((Get-Content $LogFile -Encoding UTF8 -ErrorAction SilentlyContinue)).Count } catch {}
    }

    $script:LastPSWUWriteTime = $null
    if (Test-Path $PSWUFile) {
        try { $script:LastPSWUWriteTime = (Get-Item $PSWUFile -ErrorAction SilentlyContinue).LastWriteTime } catch {}
    }

    $script:Worker = [PowerShell]::Create()
    [void]$script:Worker.AddScript($UpdateScript)
    [void]$script:Worker.AddArgument($LogFile)
    [void]$script:Worker.AddArgument($PSWUFile)
    [void]$script:Worker.AddArgument($GuiLogFile)
    $script:AsyncResult = $script:Worker.BeginInvoke()

    $script:Timer = New-Object Windows.Threading.DispatcherTimer
    $script:Timer.Interval = [TimeSpan]::FromSeconds(2)

    $script:Timer.Add_Tick({
        try {
            $DownloadActive = $false

            # Download Detection: Event ID 41 = "Ein Update wurde heruntergeladen".
            # Get-WinEvent nur 1x pro Minute, damit die GUI nicht bremst.
    if (((Get-Date) - $script:LastDownloadPoll).TotalSeconds -ge 60) {
        $script:LastDownloadPoll = Get-Date

        if (Test-DownloadActivity) {
            $script:LastDownloadEvent = Get-Date
            $script:LastRealActivity = Get-Date

            if (((Get-Date) - $script:LastDownloadLog).TotalSeconds -ge 60) {
                Write-GUILog "Download Aktivit${FS_AE}t erkannt"
                $script:LastDownloadLog = Get-Date
            }
        }
    }

# Downloadstatus nur 2 Minuten nach letztem Download-Event halten
        if (((Get-Date) - $script:LastDownloadEvent).TotalSeconds -lt 120) {
            $DownloadActive = $true
        }
        else {
            $DownloadActive = $false
        }
            $RunTime = New-TimeSpan -Start $script:StartTime -End (Get-Date)
            $RunText = "{0:00}:{1:00}:{2:00}" -f [int]$RunTime.TotalHours, $RunTime.Minutes, $RunTime.Seconds

            if ($DownloadActive) {
                $CurrentUpdateText.Text = "Windows Update Download l$($FS_AE)uft..."
                $BottomText.Text = "Grosse Updates werden heruntergeladen... Laufzeit: $RunText"

                if ($ProgressBar.Value -lt 90) {
                    $ProgressBar.Value += 2
                }
            }
            else {
                $BottomText.Text = "Windows Update arbeitet im Hintergrund... Laufzeit: $RunText"
            }

            if (((Get-Date) - $script:LastHeartbeat).TotalSeconds -ge 30) {
                try {
                    Add-Content -Path $LogFile `
                                -Value "GUI Heartbeat: Windows Update l$([char]0x00E4)uft noch... $(Get-Date -Format 'dd.MM.yyyy HH:mm:ss')" `
                                -Encoding UTF8 `
                                -ErrorAction SilentlyContinue
                } catch {}

                $script:LastHeartbeat = Get-Date
            }

            if (Test-Path $LogFile) {
                $AllLines = @(Get-Content $LogFile -Encoding UTF8 -ErrorAction SilentlyContinue)
                $Lines = $AllLines | Select-Object -Last 20

                $LogTextBox.Text = ($Lines -join [Environment]::NewLine)
                $LogTextBox.ScrollToEnd()

                $NewLines = @()
                if ($AllLines.Count -gt $script:LastLineCount) {
                    $NewLines = $AllLines[$script:LastLineCount..($AllLines.Count - 1)]
                    $script:LastLineCount = $AllLines.Count
                }

                $RealLines = $NewLines | Where-Object {
                    $_ -notmatch "GUI Heartbeat" -and
                    $_ -match "WAIT|DRIVER|TREIBER|Downloaded|Installed|Failed|Succeeded|Installation startet|Install-WindowsUpdate START|Install-WindowsUpdate ENDE|Keine Updates|Gefundene Updates|WARNUNG|FEHLER|REMAINING"
                }

                if ($RealLines) {
                    $script:LastRealActivity = Get-Date
                }

                $LastImportant = $Lines | Where-Object {
                    $_ -notmatch "GUI Heartbeat" -and
                    $_ -match "WAIT|DRIVER|TREIBER|Downloaded|Installed|Failed|Succeeded|Installation startet|Install-WindowsUpdate START|Install-WindowsUpdate ENDE|Keine Updates|Gefundene Updates|WARNUNG|FEHLER|REMAINING"
                } | Select-Object -Last 1

                if ($LastImportant) {
                    $Clean = $LastImportant -replace "^\d{2}\.\d{2}\.\d{4}\s+\d{2}:\d{2}:\d{2}\s+", ""
                    if ($Clean.Length -gt 95) {
                        $Clean = $Clean.Substring(0,95) + "..."
                    }
                    if (-not $DownloadActive) {
                        $CurrentUpdateText.Text = $Clean
                    }
                }
            }

            # Raw-Log-Änderungen zählen als echte Aktivität, ohne das Raw-Log live zu lesen.
            if (Test-Path $PSWUFile) {
                try {
                    $PSWUWriteTime = (Get-Item $PSWUFile -ErrorAction SilentlyContinue).LastWriteTime
                    if ($PSWUWriteTime -and $script:LastPSWUWriteTime -ne $PSWUWriteTime) {
                        $script:LastPSWUWriteTime = $PSWUWriteTime
                        $script:LastRealActivity = Get-Date
                    }
                } catch {}
            }

            # Solange TrustedInstaller/TiWorker aktiv sind, nicht per Idle abbrechen.
            try {
                $WUWorker = Get-Process TiWorker,TrustedInstaller -ErrorAction SilentlyContinue
                if ($WUWorker) {
                    $script:LastRealActivity = Get-Date
                }
            } catch {}

            $IdleSeconds = ((Get-Date) - $script:LastRealActivity).TotalSeconds

            if ($IdleSeconds -ge $script:IdleTimeoutSeconds) {
                try {
                    Add-Content -Path $LogFile `
                                -Value "Idle Timeout erreicht: $([int]$IdleSeconds) Sekunden ohne Windows Update Aktivit$([char]0x00E4)t." `
                                -Encoding UTF8 `
                                -ErrorAction SilentlyContinue
                    Add-Content -Path $LogFile `
                                -Value "FSC-WUP beendet ohne Fehler. Übergabe an WinUpdate_FSC.cmd." `
                                -Encoding UTF8 `
                                -ErrorAction SilentlyContinue
                } catch {}

                $script:Timer.Stop()

                try {
                    if ($script:Worker) {
                        $script:Worker.Stop()
                        $script:Worker.Dispose()
                    }
                } catch {}

                $HeaderSubText.Text = "Phase 03 - Runde $($script:UpdateRound)"
                Write-GUILog "Windows Update Runde $script:UpdateRound"
                Write-GUILog "Windows Update Suche gestartet"

                $CurrentUpdateText.Text = "Windows Update Idle Timeout. $([char]0x00DC)bergabe an FSC..."
                $BottomText.Text = "Keine Aktivit$([char]0x00E4)t erkannt. FSC übernimmt den Neustart."

                $script:CloseTimer = New-Object Windows.Threading.DispatcherTimer
                $script:CloseTimer.Interval = [TimeSpan]::FromSeconds(5)
                $script:CloseTimer.Add_Tick({
                    $script:CloseTimer.Stop()
                    $Window.Close()
                })
                $script:CloseTimer.Start()
                return
            }

            if ($script:AsyncResult -and $script:AsyncResult.IsCompleted) {
                $script:Timer.Stop()

                try {
                    $Result = $script:Worker.EndInvoke($script:AsyncResult)
                    if ($Result -and $Result.Count -gt 0) {
                        $script:ExitCode = [int]($Result | Select-Object -Last 1)
                    }
                    else {
                        $script:ExitCode = 0
                    }
                }
                catch {
                    $script:ExitCode = 99
                    try {
                        Add-Content -Path $LogFile `
                                    -Value "FEHLER EndInvoke: $($_.Exception.Message)" `
                                    -Encoding UTF8 `
                                    -ErrorAction SilentlyContinue
                    } catch {}
                }

                try { $script:Worker.Dispose() } catch {}

                $ProgressBar.IsIndeterminate = $false
                $ProgressBar.Value = 100
                $PercentText.Text = "100%"

                if ($script:ExitCode -eq 0) {
                    $HeaderSubText.Text = "Phase 03/09 $([char]0x00B7) Windows Update abgeschlossen"
                    $CurrentUpdateText.Text = "Windows Updates abgeschlossen. R$([char]0x00FC)ckgabe an FSC..."
                    $BottomText.Text = "Abgeschlossen. Das Fenster schliesst automatisch."

                    try {
                        Add-Content -Path $LogFile `
                                    -Value "Franksoft Windows Update V4.0 Ende: $(Get-Date -Format 'dd.MM.yyyy HH:mm:ss')" `
                                    -Encoding UTF8 `
                                    -ErrorAction SilentlyContinue
                    } catch {}
                }
                else {
                    $HeaderSubText.Text = "Phase 03/09 · Fehler"
                    $CurrentUpdateText.Text = "Windows Update wurde mit Fehlercode $script:ExitCode beendet."
                    $BottomText.Text = "Fehler. Details siehe C:\ProgramData\Franksoft\Logs\WindowsUpdate.log"

                    try {
                        Add-Content -Path $LogFile `
                                    -Value "Franksoft Windows Update V3.2 Fehlercode: $script:ExitCode" `
                                    -Encoding UTF8 `
                                    -ErrorAction SilentlyContinue
                    } catch {}
                }

                $script:CloseTimer = New-Object Windows.Threading.DispatcherTimer
                $script:CloseTimer.Interval = [TimeSpan]::FromSeconds(5)
                $script:CloseTimer.Add_Tick({
                    $script:CloseTimer.Stop()
                    $Window.Close()
                })
                $script:CloseTimer.Start()
            }
        }
        catch {
            $CurrentUpdateText.Text = "GUI Fehler: $($_.Exception.Message)"
            try {
                Add-Content -Path $LogFile `
                            -Value "GUI Fehler: $($_.Exception.Message)" `
                            -Encoding UTF8 `
                            -ErrorAction SilentlyContinue
            } catch {}
        }
    })

    $script:Timer.Start()
})

$Window.Add_Closed({
    try { if ($script:Worker) { $script:Worker.Dispose() } } catch {}
    try { if ($script:Mutex) { $script:Mutex.ReleaseMutex(); $script:Mutex.Dispose() } } catch {}
})

$null = $Window.ShowDialog()

try {
    Add-Content -Path $LogFile `
                -Value "PS1 ENDE ERREICHT $(Get-Date -Format 'dd.MM.yyyy HH:mm:ss')" `
                -Encoding UTF8 `
                -ErrorAction SilentlyContinue
} catch {}