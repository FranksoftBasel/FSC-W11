:: @echo off
setlocal EnableExtensions

:: =============================================================================
:: Script Name : WinUpdate_FSC.cmd
:: Version     : 1.9
:: Date        : 14.06.2026
:: Author      : Franksoft
::
:: Purpose
:: -----------------------------------------------------------------------------
:: FSC Deployment Phase 05/09
:: Microsoft Updates
:: WinGet Package Updates
::
:: Log
:: -----------------------------------------------------------------------------
:: %ProgramData%\Franksoft\Logs\Franksoft Client.txt"
:: =============================================================================

COLOR 04
@MODE CON: COLS=74 LINES=12
TITLE Franksoft Client: Windows Update - Prepare

SET FSC_STAGE=FSC_Windows_Update
@SET DBG=0
SET FSC_LOG="%ProgramData%\Franksoft\Logs\Franksoft Client.txt"
SET FSC_LOG_UPD="%ProgramData%\Franksoft\Logs\WinUpdate_FSC.log"

:: SET FSC WUP Wallpaper
REG Add "HKCU\Control Panel\Colors" /v Background /t REG_SZ /d "0 0 0" /f >NUL 2>&1
SET WallP_exe=%ProgramData%\Franksoft\Scripts\WallP.exe
SET WallPaper=%ProgramData%\Franksoft\Logos\WindowsUpdate_FSC_Logo_01.png
IF EXIST "%WallP_exe%" IF EXIST "%WallPaper%" (
    @Echo.   - Franksoft: Set Windows Update WallPaper >>%FSC_LOG%
    "%WallP_exe%" "%WallPaper%" FIT
) ELSE (
    @Echo.   - Franksoft: WallPaper NOT found %WallPaper%>>%FSC_LOG%
)
SET WallPaper=

net start dosvc 1>NUL 2>NUL
Timeout 10

FOR /F "tokens=1-3 delims=:.," %%A IN ("%TIME%") DO (
    set H=%%A
    set M=%%B
    set S=%%C
)

SET H=%H: =%
IF %H% LSS 10 SET H=0%H%
SET NT=%H%:%M%:%S%

IF Not Exist "C:\%~nx0" MD "C:\%~nx0"

SET FSC_TITLE_01=Franksoft Client: Windows Update - Prepare WLAN
SET FSC_TITLE_0x=Franksoft Client: Windows Update - Time: %NT:~0,8%
SET FSC_TITLE_LOG=Franksoft Client: Windows Update Start - Time: %NT:~0,8%

@Echo. ============================================================>>%FSC_LOG_UPD%
@Echo. WinUpdate_FSC.cmd Start - Time: %NT:~0,8%>>%FSC_LOG_UPD%
@Echo. - Version:       1.9>>%FSC_LOG_UPD%
@Echo. - Computer:      %COMPUTERNAME%>>%FSC_LOG_UPD%
@Echo. - User:          %USERNAME%>>%FSC_LOG_UPD%
@Echo. ============================================================>>%FSC_LOG_UPD%

set "Status2=00"

for %%I in (1 2 3 4 5 6 7 8 9) do (
    if exist "%TEMP%\FSC_WupStat_%%I\" (
        set "Status2=%%I"
    )
)

SET UpdatePhase=0%Status2%/09
IF NOT Exist "%Temp%\FSC_WupStat_1" SET UpdatePhase=01/09

Title %FSC_TITLE_0x% - Phase ID: %UpdatePhase%

@echo. 
@echo. 
@echo.  %FSC_TITLE_0x% - Phase ID: %UpdatePhase%

SET "DesktopOK_PATH=%ProgramData%\Franksoft\Scripts\DesktopOK"
SET "DesktopOK_VBS=%DesktopOK_PATH%\DesktopOK_Start.vbs"

IF EXIST "%DesktopOK_VBS%" "%DesktopOK_VBS%"

Openfiles 2>NUL 1>&2
IF %ErrorLevel% equ 0 (Set Admin-Status=Yes) else (Set Admin-Status=No)

:: GET Windows Setup USB Drive letter
for %%i in (B D E F G H I J K L M N O P Q R S T U V W X Y Z) do @IF Exist %%i:\Sources\setup.exe set USB_Stick_Path=%%i:

FOR /F "tokens=1-3 delims=:.," %%A IN ("%TIME%") DO (
    set H=%%A
    set M=%%B
    set S=%%C
)

SET H=%H: =%
IF %H% LSS 10 SET H=0%H%
SET NT=%H%:%M%:%S%

Set VolApp1=%ProgramData%\Franksoft\Scripts\WinAudio3.ExE
If Exist "%VolApp1%" (
		Cmd /c Start "" "%VolApp1%" 1966 >NUL
)

:: Check and Connect

SET WFWI_Profile_Path=%ProgramData%\Franksoft\FSC-Apps\Wi-Fi-cfg
SET WFWI_Profile=%WFWI_Profile_Path%\WLAN-BatMan.xml
SET WFWI_Connect_Script=%WFWI_Profile_Path%\Connect Batman.cmd

IF Exist "%TEMP%\Wlan-Connected-01" GOTO START2

IF EXIST "%WFWI_Profile%" IF EXIST "%WFWI_Connect_Script%" (
        Echo.     WLAN-Profile: Import Franksoft WLAN 
        CMD /c "%WFWI_Connect_Script%" >NUL
        MD %TEMP%\Wlan-Connected-01 >NUL
	    Timeout 4 >NUL
) ELSE (
        Echo. - WLAN Profile File not found: %WFWI_Profile% >>%FSC_LOG%
	    Timeout 10 >NUL
)

CLS

:START2

:: Check if Done
IF EXIST "%TEMP%\FSC_WupStat_9" GOTO Finish
:: If Exist "%TEMP%\FSUPD7" Goto Finish

CLS
Color 60
echo. 
echo. 
echo.  Franksoft Client: Windows Update Prepare
echo. 


If Not Exist "%Temp%\Timeout1Done" @Timeout 12
CLS

:: SET /A Status+=1

:: Temp-Verzeichnis prüfen und Status setzen
FOR %%I IN (1 2 3 4 5 6 7 8 9) DO (
    IF NOT EXIST "%Temp%\FSC_WupStat_%%I" (
        MD "%Temp%\FSC_WupStat_%%I"
        SET "Status=%%I"

        IF %%I==7 (
            Call "%ProgramData%\Franksoft\Scripts\WinGetUpdate_FSC.cmd"
            Echo.   - WinGetUpdate_FSC.cmd ReturnCode: %ERRORLEVEL%>>%FSC_LOG%
            IF DEFINED FSC_LOG_UPD Echo.   - WinGetUpdate_FSC.cmd ReturnCode: %ERRORLEVEL%>>%FSC_LOG_UPD%
        )

        GOTO EndCheckWUP
    )
)
:: -------------------------------------------------------------------------------------------------------------------------

:EndCheckWUP

SET "FSC_RUN_PHASE=%Status%"
SET Status=%UpdatePhase%
SET FSC_TITLE=Franksoft Client: Windows Update: Phase %UpdatePhase%
SET FSC_TITLE_0x=%FSC_TITLE%
SET FSC_LOG="%ProgramData%\Franksoft\Logs\Franksoft Client.txt"

:: SET /A Status+=1

@Echo. >>%FSC_LOG%
@Echo. %FSC_TITLE_LOG%>>%FSC_LOG%
@Echo. >>%FSC_LOG%

@Echo. - FSC Phase ID:   %UpdatePhase%>>%FSC_LOG%
@Echo. - Timestamp:      %Date% %NT%>>%FSC_LOG%
@Echo. - Executed by:    %UserName%>>%FSC_LOG%
@Echo. - Admin Status:   %Admin-Status%>>%FSC_LOG%
@Echo. - Script Path:    %~dp0%~nx0>>%FSC_LOG%
@Echo. >>%FSC_LOG%

If Not Exist "%Temp%\Timeout1Done" MD "%Temp%\Timeout1Done"

:::::::::::::::::::::::::::::::::::::::::: START ::::::::::::::::::::::::::::::::::::::::::

:RUN
CLS
@COLOR 20


:: Franksoft Windows Update Phase %Status% Time: %NT%
:: Franksoft Client: Windows Update Prepare

@echo. 
@echo. 
@echo.  Franksoft Client: Windows Update Start
@echo.

EVENTCREATE /T INFORMATION /so Franksoft /ID 007 /l application /d "Franksoft Client: Windows Update Start Phase: %Status% %~nx0" 1>NUL 2>NUL

@echo.   - Set Performance Power Scheme
@echo.   - Set Performance Power Scheme>>%FSC_LOG%

:: @echo. - Set Performance Power Scheme>>%FSC_LOG%
Powercfg -SetActive 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c
powercfg -change -monitor-timeout-ac 0 >NUL
powercfg -change -monitor-timeout-dc 0 >NUL

:: Disable UAC
REG ADD HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System /v EnableLUA /t REG_DWORD /d 0 /f >NUL

:: Get PS Policy
:: @FOR /F "tokens=* USEBACKQ" %%F IN (`Powershell.exe Get-ExecutionPolicy`) DO (
:: SET EP=%%F
:: )

:: SET NuGetCFG=%AppData%\NuGet\nuget.config
SET NuGetCFG=%ProgramFiles%\PackageManagement\ProviderAssemblies\nuget
If Not Exist "%NuGetCFG%" @echo. - Install: PS Module PackageProvider "NuGet"
:: If Not Exist "%NuGetCFG%" Start /min "" Powershell.exe Install-PackageProvider -Name "NuGet" -Confirm:$false -Force -Verbose >NUL
:: If Not Exist "%NuGetCFG%" Powershell.exe Install-PackageProvider -Name "NuGet" -Confirm:$false -Force -Verbose >NUL
If Not Exist "%NuGetCFG%" Powershell.exe Install-PackageProvider -Name "NuGet" -Confirm:$false -Force >NUL

SET PSWINUPDPATH=%ProgramFiles%\WindowsPowerShell\Modules\PSWindowsUpdate
If Not Exist "%PSWINUPDPATH%" @echo. - Install: PS Module PSWindowsUpdate
If Not Exist "%PSWINUPDPATH%" Powershell.exe Install-Module PSWindowsUpdate -Force >NUL

If Not Exist "%PSWINUPDPATH%" @echo. - Install: PS Module PSWindowsUpdate 
If Not Exist "%PSWINUPDPATH%" Powershell.exe Import-Module PSWindowsUpdate -Force >NUL

:: Defender Updadte

SET "FSC_DEFENDER_MARKER=%TEMP%\FSC_DefenderUpdateDone"
set "WinDefenderUpdate=%ProgramData%\Franksoft\Scripts\DefenderUpdate.cmd"

if exist "%FSC_DEFENDER_MARKER%" (
    echo.   - Defender Update: already done>>%FSC_LOG%
    IF DEFINED FSC_LOG_UPD echo.   - Defender Update: already done>>%FSC_LOG_UPD%
) ELSE (
    if exist "%WinDefenderUpdate%" (
        echo. - Update: Microsoft Defender Signatur
        echo.   - Update: Microsoft Defender Signatur>>%FSC_LOG%
        IF DEFINED FSC_LOG_UPD echo.   - Update: Microsoft Defender Signatur>>%FSC_LOG_UPD%

        call "%WinDefenderUpdate%"

        echo.   - Defender Update ReturnCode: %ERRORLEVEL%>>%FSC_LOG%
        IF DEFINED FSC_LOG_UPD echo.   - Defender Update ReturnCode: %ERRORLEVEL%>>%FSC_LOG_UPD%

        MD "%FSC_DEFENDER_MARKER%" >NUL 2>NUL
    ) ELSE (
        echo.   * Defender Update Script not found: %WinDefenderUpdate%>>%FSC_LOG%
        IF DEFINED FSC_LOG_UPD echo.   * Defender Update Script not found: %WinDefenderUpdate%>>%FSC_LOG_UPD%
    )
)

:: Defender Update END

set "WinDefenderUpdate=%ProgramData%\Franksoft\Scripts\DefenderUpdate.cmd"
SET "FSC_DEFENDER_MARKER=%TEMP%\FSC_DefenderUpdateDone"




SET NT=%TIME: =0%

@echo.   - Check Windows Updates
@echo.   - Get-WindowsUpdate>>%FSC_LOG%
IF DEFINED FSC_LOG_UPD @echo.   - Get-WindowsUpdate>>%FSC_LOG_UPD%
Powershell.exe Get-WindowsUpdate -ComputerName %COMPUTERNAME% -Confirm:$false -Force >NUL

cls
Title %FSC_TITLE_LOG% - Phase ID: %UpdatePhase%

@color 2f
@cls
echo. 
echo. 
@echo.  Franksoft Client: Windows Update RUN %NT:~0,8%
echo. 
@echo.   - Install Windows Updates
@echo.   - Install Windows Updates>>%FSC_LOG%
IF DEFINED FSC_LOG_UPD @echo.   - Install Windows Updates>>%FSC_LOG_UPD%
@echo. 
@echo. 
Powershell.exe Install-WindowsUpdate -ComputerName %COMPUTERNAME% -IgnoreReboot -Confirm:$false -Verbose -AcceptAll >NUL
@echo.   - Install-WindowsUpdate ReturnCode: %ERRORLEVEL%>>%FSC_LOG%
IF DEFINED FSC_LOG_UPD @echo.   - Install-WindowsUpdate ReturnCode: %ERRORLEVEL%>>%FSC_LOG_UPD%

@echo. Franksoft Client: Windows Update Reboot - Time: %NT:~0,8%>>%FSC_LOG%

Goto Reboot

:: -------------------------------------------------------------------------------------------------------------------------

:Finish

Title %FSC_TITLE_LOG%  - Phase ID: %UpdatePhase% - Time: %NT%
reg add "HKCU\Control Panel\Colors" /v Background /t REG_SZ /d "7 25 99" /f >NUL

SET RK_UAC=HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System

SET UAC_ON=%ProgramData%\Franksoft\Scripts\UAC-DEF.reg
If Exist "%UAC_ON%" (
    @Echo.
    @Echo.   - Windows UAC: Enable>>%FSC_LOG%
    Regedit /s "%UAC_ON%"
    REG ADD %RK_UAC% /v EnableLUA /t REG_DWORD /d 1 /f >NUL
) ELSE (
    @Echo.   * NOT found Windows UAC: "%UAC_ON%">>%FSC_LOG%
    REG ADD %RK_UAC% /v EnableLUA /t REG_DWORD /d 1 /f >NUL
)

:: SET Last Wallpaper
SET WallP_exe=%ProgramData%\Franksoft\Scripts\WallP.exe
SET WallPaper=%SystemRoot%\Web\4K\Wallpaper\Windows\FSC_Final_W11_01.jpg
IF EXIST "%WallP_exe%" IF EXIST "%WallPaper%" (
    @Echo.   - Franksoft: Set default WallPaper >>%FSC_LOG%
    "%WallP_exe%" "%WallPaper%" CENTER
) ELSE (
    @Echo.   - Franksoft: WallPaper NOT found %WallPaper%>>%FSC_LOG%
)

@Echo.   - Windows: Enable System Restore >>%FSC_LOG%
Powershell.exe -EP Bypass enable-computerrestore -drive c:\ 2>NUL

:: Gen Logfile from FS Update Log
SET FSC_LogLnk=%ProgramData%\Franksoft\Scripts\Windows Update LogFile (FS).lnk
If Exist "%FSC_LogLnk%" CMD /C Start "" "%FSC_LogLnk%"
:: Not Working from CMD
:: Powershell Get-WinEvent -FilterHashtable @{logname='system'; id=19} | Out-File $Env:ProgramData\Franksoft\Logs\FSC-Appx-Update.txt -Width 250


@Echo.
@Echo.   - Power Plan: Change to Balanced>>%FSC_LOG%
@Echo.   - Power Plan: Change to Balanced

Powercfg -SetActive 381b4222-f694-41f0-9685-ff5bb260df2e >NUL

@Echo.    - AC Monitor-timeout 10>>%FSC_LOG%
@Echo.    - DC Monitor-timeout 05>>%FSC_LOG%
@Echo.    - AC HardDisk-timeout 22>>%FSC_LOG%
@Echo.    - DC HardDisk-timeout 11>>%FSC_LOG%
@Echo.    - AC Standby-timeout 20>>%FSC_LOG%
@Echo.    - DC Standby-timeout 15>>%FSC_LOG%

:: Disable Monitor Timeout
@Echo.   - Disable: Monitor Timeout>>%FSC_LOG%
@Echo.   - Disable: Monitor Timeout

powercfg -change -monitor-timeout-ac 10 >NUL
powercfg -change -monitor-timeout-dc 5 >NUL

:: Change HardDisk Timeout
powercfg -change -disk-timeout-ac 22 >NUL
powercfg -change -disk-timeout-dc 11 >NUL

:: Change Sleep Timeout (Energiesparmodus)
powercfg -change -standby-timeout-ac 20 >NUL
powercfg -change -standby-timeout-dc 15 >NUL

@Echo.   - Disable: Hybrid Standbymode>>%FSC_LOG%
@Echo.   - Disable: Hybrid Standbymode

:: Disable Hybrid Standby
powercfg -setacvalueindex SCHEME_CURRENT SUB_SLEEP HYBRIDSLEEP 0
powercfg -setdcvalueindex SCHEME_CURRENT SUB_SLEEP HYBRIDSLEEP 0
powercfg -SetActive SCHEME_CURRENT

SET FSC_TITLE=Franksoft Client: Windows Update Completed

EVENTCREATE /T INFORMATION /so Franksoft /ID 007 /l application /d "Franksoft Client: Windows Update End   Phase: %Status% %~nx0" 1>NUL 2>NUL

:: Add Final FSC Scripts
SET REGKEY-RunOnce=HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce
SET FSC_Scripts_Local=%ProgramData%\Franksoft\Scripts
SET Audio_SCR=%FSC_Scripts_Local%\PlayAudio.vbs
SET FSC-ENDMSG_VBS=%FSC_Scripts_Local%\FSC-Complete.VBS

REG ADD "%REGKEY-RunOnce%" /v 01-FSC_END_Sound /d "CScript %Audio_SCR% //Nologo //T:05" /f >NUL
REG ADD "%REGKEY-RunOnce%" /v 02-FSC_END_CleanMgr /d "cleanmgr /sagerun:65535" /f >NUL
REG ADD "%REGKEY-RunOnce%" /v 03-FSC_END_MSG /d "%FSC-ENDMSG_VBS%" /f >NUL

EVENTCREATE /T INFORMATION /so Franksoft /ID 007 /l application /d "Franksoft Client: Windows Update Completed" 1>NUL 2>NUL
schtasks /delete /tn "Franksoft Windows Update" /f >NUL
IF Exist "C:\%~nx0" RD /S/Q "C:\%~nx0"

RD /S/Q "%TEMP%" >NUL
MD "%TEMP%" >NUL

RD /S/Q C:\Temp >NUL
MD C:\Temp >NUL

@Echo. >>%FSC_LOG%
@Echo. %FSC_TITLE%>>%FSC_LOG%
@Echo. >>%FSC_LOG%
@Echo.************************************************************************************* >>%FSC_LOG%
@Echo. >>%FSC_LOG%
IF DEFINED FSC_LOG_UPD @Echo. WinUpdate_FSC.cmd Finish erreicht - RunOnce/EndMsg vorbereitet>>%FSC_LOG_UPD%
IF DEFINED FSC_LOG_UPD @Echo. ============================================================>>%FSC_LOG_UPD%

Goto Reboot

:Reboot

SET TIMER=10

COLOR 47

@CLS
@Echo.
@Echo.
@Echo. - Reboot in %TIMER%Sec...
@Echo.
@Echo.

IF Exist "%DesktopOK_VBS%" "%DesktopOK_VBS%"
SET FSC-MSG01=Franksoft: Windows Update - Reboot in %Timer% sec
SET PSShutDownScr=%ProgramData%\Franksoft\Scripts\FS-Shutdown.ps1
SET PSShutDownEx=Powershell.exe -EP ByPass -NoLogo -NonInteractive -NoProfile -WindowStyle Hidden -File "%PSShutDownScr%"

IF Exist "%PSShutDownScr%" ( 
            %PSShutDownEx% 
) else (
            Shutdown -r -f -t %Timer% /c "%FSC-MSG01%"
)

Exit /b