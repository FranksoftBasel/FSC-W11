
@echo off
TITLE Setting-up RunOnceEx
CLS

IF EXIST "%WINDIR%\SysWOW64" (
    SET ARCH=x64
) ElSE (
    SET ARCH=x86
)


call :Admin

SET Win_Title=Franksoft Client Apps-Deployment


::::::::: ----- SET Needed FSC Variables ----- :::::::::

:: Check USB Drive
for %%i in (B D E F G H I J K L M N O P Q R S T U V W X Y Z) do @IF Exist %%i:\Sources\setup.exe set USB_Stick_Path=%%i:

SET FSLOG="%ProgramData%\Franksoft\Logs\Franksoft Client.txt"
If Not Exist %ProgramData%\Franksoft\Logs MD %ProgramData%\Franksoft\Logs

:: @Echo. >>%FSLOG%
:: @Echo. FSC Setup phase...: Franksoft Windows Client Post-Setup>>%FSLOG%
:: @Echo. Time/Date.........: %NT:~0,-3% - %Date%>>%FSLOG%
:: @Echo. User Name.........: %UserName%>>%FSLOG%
:: @Echo. User Is Admin.....: %Admin%>>%FSLOG%
:: @Echo. Power Scheme......: %CurPowerP%>>%FSLOG%
@Echo. - Franksoft Client Apps-Deployment Script Start .: Time: %Time:~0,-3% Script: %~dp0%~nx0
:: @Echo. >>%FSLOG%

::::::::: ----- Start FS RunOnceEx ----- :::::::::

SET SourcePath=%~dp0Install
:: @echo. SourcePath = %SourcePath%

SET TitleDialog="%Win_Title%"

:: FOR %%I IN (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z) DO IF EXIST %%I:\sources\install.esd SET DRIVE=%%I:
:: IF "%DRIVE%" == "" FOR %%I IN (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z) DO IF EXIST %%I:\sources\install.wim SET DRIVE=%%I:
:: IF "%DRIVE%" == "" FOR %%I IN (A B C D E F G H I J K L M N O P Q R S T U V W X Y Z) DO IF EXIST %%I:\sources\install.swm SET DRIVE=%%I:


SET ROE=HKLM\Software\Microsoft\Windows\CurrentVersion\RunOnceEx
SET i=100

	REG ADD %ROE% /v Title /d "Franksoft Client Apps-Deployment" /f
	REG ADD %ROE% /v Flags /t REG_DWORD /d "00000024" /f

	REG ADD %ROE%\%i% /ve /d "Adobe AIR" /f
	REG ADD %ROE%\%i% /v "001" /d "%SourcePath%\Adobe\AIR\FS-Loader.ExE" /f
	SET /A i+=1

	REG ADD %ROE%\%i% /ve /d "Adobe Reader DC" /f
	REG ADD %ROE%\%i% /v "001" /d "%SourcePath%\Adobe\ReaderDC_GE\FS-Wrapper.exe" /f
	REG ADD %ROE%\%i% /v "002" /d "REGEDIT /S %SourcePath%\Adobe\ReaderDC_GE\Acrobat_GPO.reg" /f
	SET /A i+=1

If Not Exist "%ProgramFiles%\Desktop Restore\dkticnsr.dll" (
	REG ADD %ROE%\%i% /v "001" /d "%SourcePath%\DesktopRestore\DesktopRestoreInstall.exe /NOCANCEL /NORESTART /FORCECLOSEAPPLICATIONS /SILENT /SUPPRESSMSGBOXES /NOICONS" /f

)

	REG ADD %ROE%\%i% /ve /d "Desktop Restore" /f
	REG ADD %ROE%\%i% /v "002" /d "REGEDIT /S %SourcePath%\DesktopRestore\DesktopRestore.reg" /f
	SET /A i+=1

	REG ADD %ROE%\%i% /ve /d "Google Chrome" /f
	REG ADD %ROE%\%i% /v "001" /d "%SourcePath%\Chrome\FS-Wrapper.exe" /f
	REG ADD %ROE%\%i% /v "002" /d "REGEDIT /S %SourcePath%\Chrome\CU\Chrome-HKCU_FSC-01.reg" /f
	SET /A i+=1

	REG ADD %ROE%\%i% /ve /d "Hyper Snap" /f
	REG ADD %ROE%\%i% /v "001" /d "%SourcePath%\HyperSnap\FS-Loader.exe" /f
	SET /A i+=1

	REG ADD %ROE%\%i% /ve /d "Microsoft Edge" /f
	REG ADD %ROE%\%i% /v "000" /d "%SourcePath%\_Microsoft\Microsoft.RemoteDesktop_2025.cmd" /f
	REG ADD %ROE%\%i% /v "001" /d "%SourcePath%\_Microsoft\Edge\KillEdge.vbs" /f
	REG ADD %ROE%\%i% /v "002" /d "%SourcePath%\_Microsoft\Edge\FS-Wrapper.exe" /f
	REG ADD %ROE%\%i% /v "003" /d "REGEDIT /S %SourcePath%\_Microsoft\Edge\CU\MS-EDGE-HKCU_FSC-01.reg" /f
	SET /A i+=1

	REG ADD %ROE%\%i% /ve /d "Microsoft OneDrive" /f
	REG ADD %ROE%\%i% /v "001" /d "%SourcePath%\_Microsoft\OneDriveSetup_Kill.vbs" /f
	REG ADD %ROE%\%i% /v "002" /d "%SourcePath%\_Microsoft\OneDriveSetup.exe /silent /allusers" /f
	SET /A i+=1

	REG ADD %ROE%\%i% /ve /d "Media Player Classic" /f
	REG ADD %ROE%\%i% /v "001" /d "%SourcePath%\MPC-HC\FS-Loader.exe" /f
	SET /A i+=1


	REG ADD %ROE%\%i% /ve /d "SafeGuard PrivateCrypto" /f
	REG ADD %ROE%\%i% /v "001" /d "%SourcePath%\SafeGuardPC\FS-Wrapper.exe" /f
	SET /A i+=1

	REG ADD %ROE%\%i% /ve /d "VLC Media Player" /f
	REG ADD %ROE%\%i% /v "001" /d "%SourcePath%\VLC_media_Player\FS-Wrapper.exe" /f
	SET /A i+=1

	REG ADD %ROE%\%i% /ve /d "7-Zip" /f
	REG ADD %ROE%\%i% /v "001" /d "%SourcePath%\7Zip\FS-Wrapper.exe" /f
	SET /A i+=1
	
	REG ADD %ROE%\%i% /ve /d "WinRAR" /f
	REG ADD %ROE%\%i% /v "001" /d "%SourcePath%\WinRar\FS-Wrapper.exe" /f
	SET /A i+=1

	REG ADD %ROE%\%i% /ve /d "Franksoft Remote Support" /f
	REG ADD %ROE%\%i% /v "001" /d "%SourcePath%\FSR.ExE" /f
	SET /A i+=1

	REG ADD %ROE%\%i% /ve /d "Franksoft Cleanup" /f
	REG ADD %ROE%\%i% /v "001" /d "CMD /C MD %Temp%\FSRunOnce_Done" /f
	SET /A i+=1

:: FSC Check File: Update_All_00.cmd Section :WFSCRU
	
::	REG ADD %ROE%\%i% /ve /d "Open Shell" /f
::	REG ADD %ROE%\%i% /v "001" /d "%SourcePath%\ClassicShell\FS-Wrapper.exe" /f
::	SET /A i+=1


:: 	REG ADD %ROE%\%i% /ve /d "DBG Stop" /f
:: 	REG ADD %ROE%\%i% /v "002" /d "Notepad" /f
:: 	SET /A i+=1

:: %SystemRoot%\System32\runonce.exe /Explorer
@Echo. - FSC RUO Script    ...: Time: %Time:~0,-3% Script: %~dp0%~nx0>>%FSLOG%

:::: Start RU Process
:: start "" runonce.exe /Explorer
:: exit


:Admin
reg query "HKU\S-1-5-19\Environment" >nul 2>&1
if not %errorlevel% EQU 0 (
    cls
    powershell.exe -windowstyle hidden -noprofile "Start-Process '%~dpnx0' -Verb RunAs"
    exit
)


:Admin
reg query "HKU\S-1-5-19\Environment" >nul 2>&1
if not %errorlevel% EQU 0 (
    cls
    powershell.exe -windowstyle hidden -noprofile "Start-Process '%~dpnx0' -Verb RunAs"
    exit
)



